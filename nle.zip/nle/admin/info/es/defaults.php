<h3>A&ntilde;adir algunos atributos &uacute;tiles</h3>
Escoja los atributos que quiere a&ntilde;adir a su sistema de listas
de correo: