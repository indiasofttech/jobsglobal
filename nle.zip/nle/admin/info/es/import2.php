Aqu&iacute; puede a&ntilde;adir m&uacute;ltiples emails a sus
listas. Los atributos tienen que estar identificados en la primera
l&iacute;nea del fichero. No ser&aacute;n creados como atributos de
l&iacute;nea de texto si no existen ya.
