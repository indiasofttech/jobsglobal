<p>Esta es la lista de correos rebotados. En la mayor parte de los
casos se identifican con un usuario y un mensaje concretos. Si su
sistema est&aacute; en uso no elimine los rebotes, porque entonces el
sistema no podr&iacute;a identificar los rebotes consecutivos cuando
estos se produzcan. De momento solo se pueden ver los rebotes, no hay
modo (aun) de invalidar la identificaci&oacute;n que el sistema hace
de un rebote. En algunos casos esto puede suponer que algo queda
marcado como rebote cuando no era m&aacute;s que un error temporal
tipo &#171;buz&oacute;n lleno&#187;.</p>
