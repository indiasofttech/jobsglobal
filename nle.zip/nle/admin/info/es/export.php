Puede exportar usuarios usando la fecha como criterio.<br/>
Si hace click en &#171;Exportar&#187; se abrir&aacute; un cuadro de
di&aacute;logo para descargar un fichero. Este es un fichero de texto
de valores delimitados por tabulaci&oacute;n que contiene los datos que usted seleccione para exportar.<br/>
Este fichero se puede leer con la mayor&iacute;a de los programas de
hoja de c&aacute;lculo.
