<h3>The suppression list</h3>
<p>The suppression list allows you to ensure that your campaigns will not go out to some subscribers.</p>
<p><strong>Warning</strong> If you check the box to make it permanent, there is no way to revert this. Any emails you add to the permanent suppression list will stay there forever.</p>

<p>If you want to temporarily avoid sending to certain subscribers, the best method is to create a list with those subscribers and use the "List-Exclude" functionality to ensure they do not receive the campaign.</p>

