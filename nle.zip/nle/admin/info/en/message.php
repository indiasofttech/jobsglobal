<br /><a href="#resend">Send this message to a different list</a>
