<p>Here you can identify the attributes you want administrators to enter, which can be included in emails they send to their list(s).
</p>
<p><a href="#new">Add a new one</a></p>