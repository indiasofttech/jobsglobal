<p class="information">To send a campaign fill out the information below. The minimum requirement for a valid campaign
is the information in the "Content" and the "Lists" tab.<br/>
To test the campaign before sending, use the "Send Test" functionality on the right.<br/>
To finish your campaign and send it to your subscribers, load the "Finish" tab and click the button "Send Campaign"</p>
