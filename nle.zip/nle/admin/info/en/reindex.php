
<h3>Rebuilding database indexes, please wait</h3>
<p>This page will check on Database indexes and re-create them if they don't exist. If you have a lot of entries in your database, it is quite likely to time out.</p>
<p>If it times out, you can reload this page a few times to try again</p>


