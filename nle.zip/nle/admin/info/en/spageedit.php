<p>This page allows you to create pages that are used for users to subscribe to your lists.</p>
<p>You can select any set of attributes and lists that are defined in your system. If a list or
attribute is not listed here, you need to add them first. Values for attributes default to your
global attribute values, but you can re-order them here, and add different default values. You can also
change whether an attribute is required or not. This will only have an effect on the requiredness of the attributes
when users use this page to sign up.</p>