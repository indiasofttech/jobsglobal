
<p>This page allows you to categorise lists that do not have a category assigned</p>

<p>Once they have a category, they will disappear here, and you can edit the category when you edit the list</p>
