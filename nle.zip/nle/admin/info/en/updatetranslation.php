<p>Here you can update the translations for phpList from the <a href="http://translate.phplist.com">community translation website</a>. This will update the short texts found across the application</p>
<p>The translation of phpList is a community effort. If you find missing translations in your language, feel free to help out improving the translation.</p>
