<p>This is the list of bounces received. In most cases they will be identified for a user and
a message. If you run a live system, do not delete the bounces, because the system would not be able to
identify the consecutive bounces, once more bounces come back. Currently you can only view a bounce,
there is no way (yet) to override the system identification of the bounce. In some cases this may
mean that something is marked as a bounce, when it was only a "Mailbox full" temporary error.</p>
