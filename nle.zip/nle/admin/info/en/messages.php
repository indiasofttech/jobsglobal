You can use "Requeue" to resend a campaign. This will cause the campaign to be sent to subscribers who sign up later. It will not be sent to subscribers who have already received the campaign.
<p>If you view a campaign, you will be able to resend it to a different list</p>
<?php if (TEST) {
    ?>
<br /><b>Note:</b> You are operating in test mode, so campaigns will be "resend" to subscribers who have received it.
<?php 
} ?>
