Az "Ismételt várólistára vétel" funkcióval újraküldhet egy üzenetet. Ez azt fogja előidézni, hogy az üzenetet azoknak a felhasználóknak fogja elküldeni, akik az üzenet küldése után iratkoztak fel. Nem fogja elküldeni azoknak a felhasználóknak, akik már megkapták az üzenetet.
<p>Ha megtekint egy üzenetet, akkor újra tudja egy másik listának küldeni</p>
<?php if (TEST) {
    ?>
<br /><b>Megjegyzés:</b> Ön most teszt módban dolgozik, ezért az üzeneteket azoknak a felhasználóknak "küldi újra", akik megkapták.
<?php 
} ?>
