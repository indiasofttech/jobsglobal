A felhasználókat dátum alapján exportálhatja.<br/>
Az "Exportálás" gombra kattintáskor megjelenik egy előugró panel egy fájl letöltéséhez. Ez a fájl
az exportálási lekérdezés eredményét tartalmazó tabulált szövegfájl lehet.<br/>
Ezt a fájlt a legtöbb táblázatkezelő alkalmazásban meg tudja nyitni.