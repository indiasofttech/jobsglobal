<br/>
<p>Köszönjük, hogy a <?php echo NAME?>et használja.<br/>Reméljük, elérte célját.</p>
<p>Ön most kijelentkezett.</p>
<p>Ha be szeretne ismét jelentkezni, akkor kattintson <a href='?page=home'>ide</a>.</p>

