<p>Töltse ki az alábbi adatokat az üzenet küldéséhez. Az érvényes üzenet legkisebb követelménye
a "Tartalom" fülön lévő információk. Győződjön meg róla, hogy új fülre váltás előtt mentette-e 
a változtatásokat, mert különben el fognak veszni. Az üzenet befejezéséhez és igaziból történő küldéséhez 
válassza a "Listák" fület, 
jelölje ki a listákat, majd nyomja meg az "Üzenet küldése a kiválasztott levelező listákra" gombot.</p>