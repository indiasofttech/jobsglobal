<br /><?php echo PageLink2('messages', 'Vissza az üzenetlistához')?>
<br /><a href="#resend">Az üzenet küldése egy másik listára</a>
