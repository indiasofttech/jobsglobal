<h3>Több rendelési oldal készítése.</h3>
<p>Ezen az oldalon készíthet olyan oldalakat, melyeken a felhasználók feliratkozhatnak az Ön listáira.</p>
<p>A rendszerben létrehozott bármelyik tulajdonságkészletet és listát választhatja. A tulajdonságok értékei 
a tulajdonságok globális értékeinek alapértelmezései, azonban átrendezheti őket, és különböző alapértelmezett értékeket adhat nekik.
Azt is módosíthatja, 
hogy egy tulajdonság megadása kötelező-e vagy sem. Ennek csak a tulajdonságok kötelezővé tételében van hatásuk, amikor a felhasználók
jelentkezésre használnak egy oldalt.</p>
