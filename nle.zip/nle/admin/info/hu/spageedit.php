<p>Ezen az oldalon hozhatja létre azokat az oldalakat, melyeken a felhasználók feliratkozhatnak a listákra.</p>
<p>Bármelyik, a rendszerben meghatározott attribútumkészletet és listát választhatja. Ha egy lista
vagy attribútum nem szerepel ebben a listában, akkor előbb hozzá kell adnia őket. A tulajdonságok értékei 
az attribútumok globális értékeinek alapértelmezései, viszont itt átrendezheti őket, és más alapértelmezett értékeket adhat hozzá.
Azt is módosíthatja, hogy egy tulajdonság megadása kötelező legyen-e. Ennek csak a tulajdonságok kötelezővé tételére van hatásuk,
amikor a felhasználók ezt az oldalt használják a jelentkezéshez.</p>