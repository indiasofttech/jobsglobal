<h3>Néhány valószínűleg hasznos tulajdonság hozzáadása</h3>
Válassza ki a levelező lista rendszerhez hozzáadni kívánt tulajdonságokat: