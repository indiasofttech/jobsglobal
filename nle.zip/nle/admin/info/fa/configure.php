<p>اینجا باید مقدارهای درست را برای سایتِ وب خود مشخص کنید.<br/>
می‌توانید از 
<b>جا نگهدارهای</b> خاصی در مقدارهایتان استفاده کنید.
جا نگهدارها شبیه 
<b>[SOMETEXT]</b> هستند، البته, به جای <i>SOMETEXT</i> چیز دیگری نوشته می‌شود.
تعدادی از جا نگهدارهای سودمند به شرح زیرند:
<ul>
<li>WEBSITE - نشانیِ سایت شما
<li>DOMAIN - متنی که برای دامنه خود تایپ می‌کنید
<li>SUBSCRIBEURL - نشانی برگه اشتراک
<li>UNSUBSCRIBEURL - نشانی برگه لغو اشتراک
<li>BLACKLISTURL - نشانی برگه لغو اشتراک کاربران ناشناس
<li>PREFERENCESURL - نشانیِ برگه‌ای که کاربران میتوانند مشخصات خود را تغییر دهند
<li>CONFIRMATIONURL - نشانیِ برگه‌ای که کاربران باید اشتراکشان را تایید کنند
</ul>
<!--For the header and the footer you can use the following code to include external documents:
<br/>
<b>[URL:&lt;Full URL of page to load&gt;]</b>-->
</p>
