<br /><?php echo PageLink2('messages', 'بازگشت به فهرست پیامها')?>
<br /><a href="#resend">این پیام را برای فهرست دیگری بفرست</a>
