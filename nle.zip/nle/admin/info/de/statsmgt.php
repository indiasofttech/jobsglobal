<p>Hier haben Sie Zugriff auf die verf&uuml;gbaren Statistikfunktionen.
Die Statistiken sind derzeit noch nicht sehr ausgereift und m&uuml;ssen in zuk&uuml;nftigen PHPlist-Versionen noch &uuml;berarbeitet werden.
F&uuml;r Kommentare und Verbesserungsverschl&auml;ge benutzen Sie bitte den <a href="http://mantis.phplist.com">phpList Bug Tracker</a>.</p>