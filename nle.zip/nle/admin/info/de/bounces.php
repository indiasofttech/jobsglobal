<p>Dies ist die Liste der unzustellbaren Mails (Retouren).
Meistens sind sie &uuml;ber den Empf&auml;nger und die Nachricht identifizierbar.
Wenn Sie ein Live-System betreiben, dann sollten Sie die Retouren nicht l&ouml;schen, 
weil sonst das System aufeinanderfolgende unzustellbare Mails nicht erkennen kann.</p>
<p>In der aktuellen Version von PHPlist k&ouml;nnen unzustellbare Mails lediglich angezeigt werden;
es gibt derzeit keine M&ouml;glichkeit, ihre Erkennung durch das System zu beeinflussen.
In gewissen F&auml;llen kann auch die Fehlermeldung einer tempor&auml;re &uuml;berf&uuml;llten Mailbox als unzustellbare Mail gewertet werden.</p>
