<br/>
<p>Sie sind nun abgemeldet.<br />Danke, dass Sie PHPlist benutzt haben.</p>
<p>Um sich erneut anzumelden <a href='?page=home'>klicken Sie hier</a>.</p>

