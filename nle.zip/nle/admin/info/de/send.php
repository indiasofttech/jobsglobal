<p>Damit eine Nachricht gesendet werden kann m&uuml;ssen mindestens alle Felder im Register "Inhalt" ausgef&uuml;llt sein.
Bitte speichern Sie Ihre &Auml;nderungen, bevor Sie auf ein anderes Register wechseln, sonst werden diese &Auml;nderungen verworfen.
Um eine Nachricht zu senden, wechseln Sie auf das Register "Listen", w&auml;hlen die gew&uuml;nschten Listen und klicken auf den Button [Nachricht senden].
</p>