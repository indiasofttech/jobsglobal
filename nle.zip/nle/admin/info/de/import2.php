Bei dieser Importmethode d&uuml;rfen die importierten Adressdaten auch Attribute enthalten, die im System noch nicht existieren.
Diese werden dann beim Import automatisch angelegt und als einzeilige Textattribute definiert.
Die individuellen Attributwerte der Abonnenten bleiben beim Import erhalten.
Benutzen Sie diese Option, wenn Sie Daten aus einer Tabellenkalkulation bzw. einer CSV-Datei importieren,
welche die Attribute spaltenweise und die Abonnenten zeilenweise enthält.
Die Attributnamen m&uuml;ssen dabei in der ersten Zeile der Datei stehen.
<br /><br />
<?php echo PageLink2('import', 'Andere Importmethode w&auml;hlen');?>
<br /><br />

