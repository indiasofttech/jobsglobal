<br /><?php echo PageLink2('messages', 'Liste aller Nachrichten anzeigen')?>
<br /><br />Sie k&ouml;nnen diese Nachricht an weitere Listen senden. Die entsprechende Funktion finden Sie am <a href="#resend">Seitenende</a>.
