<p>Pour envoyer un message, remplissez les champs situ&eacute;s ci-dessous.<br>
Pour qu'un message puisse &amp;ecirc;tre valid&eacute;, il est obligatoire qu'en plus du champ "objet" le champ message comprenne au moins un caract&egrave;re.
N'oubliez pas de sauvegarder vos modifications avant de cliquer sur un autre onglet, sinon vous perdriez toutes vos modifications.<br>
Pour terminer votre message et l'envoyer <i>effectivement</i>, choisissez l'onglet "Listes", choisissez vos listes et cliquez sur le bouton : "Envoyer le message aux listes s&eacute;lectionn&eacute;es". </p>