<h3>Ajoutez des attributs qui peuvent &amp;ecirc;tre utiles</h3>
Choisissez les attributs par d&eacute;faut que vous voulez ajouter &amp;agrave; votre syst&egrave;me de listes de diffusion :