<p>Vous trouverez ici la liste des messages qui ont &eacute;t&eacute; rejet&eacute;s (qui sont revenus).<br>
Dans la plupart des cas, ils seront identifiables par le nom du destinataire et le message envoy&eacute;.<br>
Si vous travaillez en ligne, n'effacez pas ces messages rejet&eacute;s, parce que le syst&egrave;me ne sera plus capable
ult&eacute;rieurement d'identifier les rejets suivants et les messages en retour s'accumuleront.
Pour le moment, vous pouvez seulement voir qu'il y a un message rejet&eacute;.<br>
En l'&eacute;tat actuel du programme, il n'y a pas moyen de passer outre l'identification du message rejet&eacute; 
par le syst&egrave;me. Dans certains cas, un message peut &amp;ecirc;tre marqu&eacute; comme retourn&eacute; alors que l'erreur &eacute;tait
simplement due au fait que la boite du destinataire &eacute;tait momentan&eacute;ment pleine.</p>