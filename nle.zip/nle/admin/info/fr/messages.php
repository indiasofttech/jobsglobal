Vous pouvez choisir de "Remettre dans la file d'attente" un message pour le renvoyer. Ceci enverra le message aux destinataires qui se seront inscrits sur la liste apr&egrave;s votre premier envoi. Mais cela ne renverra pas le message aux destinataires qui ont d&eacute;j&amp;agrave; re&amp;ccedil;u le message. <p>Si vous affichez un message, vous pourrez le renvoyer &amp;agrave; une autre liste. </p>
<?php if (TEST) {
    ?>
<br /><b>Note:</b> Vous travaillez en mode test; les messages seront "Renvoy&eacute;s" aux destinataires qui l'ont d&eacute;j&amp;agrave; re&amp;ccedil;u. <?php 
} ?>