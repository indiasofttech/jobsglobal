<br/>
<p>Merci d'avoir utilis&eacute; <?php echo NAME?>. <br/>Nous esp&eacute;rons que vous &amp;ecirc;tes satisfait(e). </p>
<p>Vous &amp;ecirc;tes maintenant d&eacute;connect&eacute;(e). </p>
<p>Pour vous reconnecter, cliquez <a href='?page=home'>ici</a>. </p>