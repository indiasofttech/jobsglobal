<?php

## show notes

$_SESSION['suppressinfo'] = array();
$status = ' ';
