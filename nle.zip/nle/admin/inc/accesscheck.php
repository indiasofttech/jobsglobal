<?php

if (!function_exists('checkAccess')) {
    print 'Invalid Request';
    exit;
}
