
<h3>The content of your campaign</h3>

<p>There are two ways to specify the content of your campaign</p>

<h2>1. Send a Web page</h2>

<p>When sending a web page, all you need to do is specify the URL of the webpage you want to send. phpList will fetch the URL, and send it to your subscribers.</p>
<p>Images will live on the website you send.</p>

<h2>2. Compose the content</h2>

<p>You can enter the content of your campaign in the box below.</p>
<p>If configured for it, you can upload the images to the phpList server.</p>
