
<h3>Generate text version from HTML</h3>

<p>This will use the phpList HTML to text conversion to pre-fill the text version of the campaign, based on the content of the HTML version</p>
<p>Any content already in the input box for the text version will be removed.</p>

<p><b>Note:</b> this process fails when the HTML content is very large.</p>
