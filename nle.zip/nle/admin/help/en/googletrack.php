
<h3>Google Tracking code</h3>

<p>If you use Google Analytics on your website this is a great way to see the results of your campaigns.</p>
<p>Selecting this option will add some tracking code to all links.
After sending your campaign, check your Google Analytics account under <strong>Traffic sources -&gt; Campaigns</strong> to see the results.</p>

<p>Do not use this if your campaign already contains Google Analytics links, because existing ones will be removed.</p>

