
<h3>Reset click and open statistics</h3>

<p>Check the box to clear existing click and open statistics for this campaign.</p>
<p>If you have been sending test mails and clicked the links, to make sure everything works as desired, the database may have some click statistics that you want to clear.</p>
<p>Make sure not to check this once your main campaign has started, otherwise statistics from real subscribers will be cleared as well.</p>



