Enter the subject of your campaign. You cannot use placeholders in the subject. This is the first thing your subscribers see, so it is very important to choose a good subject.
