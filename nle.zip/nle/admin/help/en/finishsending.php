<h3>Stop sending after</h3>
<p>To make sure that your campaign does not continue sending after a certain time, set this value.</p>
<p>This particularly useful if your campaign involves some event in the future. Using this setting, you can
avoid your subscribers to receive a message when the event has already taken place.
</p>
