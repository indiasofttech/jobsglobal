
<h3>Test campaign</h3>

<p>If you are sending this campaign as a test to a small list of subscribers, check the box.</p>
<p>This will add the option to delete the campaign from the list of finished or active campaigns.</p>

<p>It is not recommended to do this for your final campaigns, because deletion of a campaign will cause all the links in the message that your subscribers have received to stop working. When a subscriber clicks a link in a campaign that no longer exists, they will get a "404 - File Not Found" error message.</p>



