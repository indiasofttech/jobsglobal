The campaign title is for your own use only. It is not visible to your subscribers and it will not be used in the outgoing emails.

