<p>Je kunt meerdere bijlagen aan het bericht toevoegen, maar het aantal dat je hier ziet
is vastgelegd in de instellingen.</p>
<p><b>Let op:</b> Bijlagen worden toegevoegd aan e-mail berichten met HTML opmaak, bij  e-mail berichten met tekst opmaak zal er een link naar de website toegevoegd worden.</p>
<p>Het onderwerpveld wordt enkel in  e-mail berichten met tekst opmaak gebruikt.</p>