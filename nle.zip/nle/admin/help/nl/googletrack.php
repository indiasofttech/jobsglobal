
<h3>Google Tracking code</h3>

<p>Als je  Google Analytics gebruikt dan kun je hiermee de resultaten van het verzenden van berichten via phpList bekijken.</p>
<p>Als je deze optie selecteert dan wordt er een "tracking code" toegevoegd aan alle links.
Nadat je het e-mail bericht hebt verzonden kun je op je  Google Analytics account de resultaten bekijken.</p>



