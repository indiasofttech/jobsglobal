<b>Het plannen van een e-mail bericht</b>
<p>Het is mogelijk om een e-mail bericht op een bepaald tijdstip te verzenden.
Een bericht zonder opgave van een tijdstip wordt onmiddellijk verzonden. </p>
<p><b>Let op</b>: Het plannen van een e-mail bericht heeft enkel invloed op de tijd dat het verzenden van het bericht begint.
Dit wil niet zeggen dat de berichten op dat moment zullen aankomen bij de gebruikers.
</p>