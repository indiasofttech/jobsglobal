<h3>Niet verzenden na een bepaalde tijd</h3>
<p>Om er zeker van te zijn dat een bericht niet na een bepaalde tijd wordt verzonden moet je hier een tijdstip invullen.</p>
<p>Dit is belangrijk als een bericht een gebeurtenis beschrijft welke in de toekomst plaats zal vinden. Door deze instelling te gebruiken kun je voorkomen dat gebruikers een bericht ontvangen van een gebeurtenis die al heeft plaatsgevonden.
</p>
