
<h3>De inhoud van het bericht</h3>

<p>Er zijn twee manieren om de inhoud van je bericht te specificeren:</p>

<h3>1. Verstuur een pagina van een website</h3>

<p>Als er een pagina van een website wordt verzonden, dan hoef je alleen maar de URL van de pagina van de website in te voeren. PhpList zal de inhoud van de pagina van de website toevoegen en naar de abonnees sturen. De afbeeldingen zullen direct van de website worden gehaald als de gebruiker het bericht opent.</p>
<h3>2. De inhoud zelf samen stellen</h3>

<p>De inhoud van het bericht kun je in het veld hieronder invoeren. Afbeeldingen kun je naar de phpList server uploaden als je dat zo hebt ingesteld.</p>
