
<h3>Het opnieuw versturen van een e-mail bericht</h3>

<p>Als je ervoor kiest om een e-mail bericht opnieuw te verzenden, dan zal het e-mail bericht opnieuw worden verzonden nadat het bericht een eerste keer is verzonden. Het e-mail bericht wordt gepland aan de hand van het tijdstip dat je hier kiest.
</p>

<p>Het e-mail bericht wordt op deze manier verzonden aan abonnees welke zich hebben ingeschreven nadat het bericht voor de eerste keer was verzonden.</p>

