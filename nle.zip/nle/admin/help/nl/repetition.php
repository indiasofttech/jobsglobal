Deze optie maakt het mogelijk om automatisch een nieuw bericht aan te maken
dat een exacte kopie is van het huidige bericht, waarbij tevens een interval wordt ingegeven.
Als je deze optie gebruikt, dan is het belangrijk om de planningsoptie ook te gebruiken, anders
zal je bericht meerdere keren worden verzonden. De abonnees krijgen op deze manier telkens dezelfde berichten.


