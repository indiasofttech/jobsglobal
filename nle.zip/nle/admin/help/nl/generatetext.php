
<h3>Het genereren van een tekst opmaak vanuit een HTML opmaak</h3>

<p>Hiermee kan de phpList HTML opmaak naar een bericht met tekst opmaak converteren, gebaseerd op de inhoud van de HTML versie.</p>
<p>Alle inhoud die reeds aanwezig is in het invoerveld zal worden verwijderd.</p>


