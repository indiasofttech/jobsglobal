<p>Als je een sjabloon gebruikt, dan zal het bericht worden geplaatst op de plek waar [CONTENT] in je sjabloon staat.</p>
<p>Naast [CONTENT], kun je [FOOTER] en [SIGNATURE] gebruiken om  voet (ook wel: footer) informatie en de handtekening van het bericht mee te sturen. Deze zijn optioneel.</p>
