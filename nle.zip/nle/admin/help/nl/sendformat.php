Als dit bericht een HTML opmaak heeft,
geef dan aan hoe je het wilt verzenden:<br />
<ul>
<li><b>HTML</b> - HTML aan abonnees die hebben aangegeven dat ze e-mail berichten in HTML-opmaak willen ontvangen, en tekst opmaak naar alle andere abonnees</li>
<li><b>tekst</b> - tekst opmaak naar alle abonnees</li>
<li><b>PDF</b> - tekst opmaak als een PDF-bijlage</li>
<li><b>tekst en PDF</b> - tekst opmaak én een PDF bijlage in één e-mail bericht</li>
</ul>

<b>Let op:</b> de PDF versie zal een geconverteerde versie van de tekst opmaak zijn, niet van de HTML-opmaak.