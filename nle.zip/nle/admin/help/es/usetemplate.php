<p>Si utiliza una plantilla, este mensaje aparecer&aacute; en el lugar indicado por el marcador [CONTENT] de la plantilla.</p>
<p>Adem&aacute;s de [CONTENT] puede incluir [FOOTER] y [SIGNATURE] para incluir un pie de mensaje y una firma respectivamente. Esto es opcional.</p>
