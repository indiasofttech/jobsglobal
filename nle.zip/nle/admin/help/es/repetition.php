Esta opción le da la posibilidad de hacer que el sistema cree automáticamente un mensaje nuevo, copia exacta del mensaje actual, que será reenviado regularmente. Se puede establecer el plazo que separa cada iteración del mensaje.
Si utiliza esta opción es importante utilizar también la opción «Embargo», porque de otro modo su mensaje se enviará continuamente, inundando a sus usuarios con un montón de mensajes idénticos.

