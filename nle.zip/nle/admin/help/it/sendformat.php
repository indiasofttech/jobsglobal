Se questo messaggio &egrave; stato formattato in HTML, indicate come desiderate inviarlo:<br />
<ul>
<li><b>HTML</b> - Formato HTML col testo nascosto per gli utenti che hanno indicato di voler ricevere le email solo in formato HTML, e formato testo per tutti gli altri</li>
<li><b>Testo</b> - solo formato testo per tutti</li>
<!-- li><b>Testo e HTML</b> - Un' unica grande email che contiene entrambi i formati HTML e testo (emails corpose, ma meglio utilizzabili dalla maggior parte degli utenti)</li>  -->
<li><b>PDF</b> - Il contenuto del messaggio nel formato testuale viene inviato come allegato PDF</li>
<li><b>Testo e PDF</b> - Una email che contiene solo il messaggio in formato testo con un allegato PDF</li>
</ul>
<b>Nota:</b>La versione PDF sar&agrave; il risultato della conversione del messaggio dal formato di testo, non dal messaggio in HTML.
