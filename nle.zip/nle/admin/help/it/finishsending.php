<h3>Ferma l'invio dopo il</h3>
<p>Per assicurarvi che il sistema non continui ad inviare messaggi dopo una certa ora, impostate questo valore.</p>
<p>Questo &egrave; particolarmente utile se la vostra newsletter include eventi futuri. Utilizzando questa impostazione, potete evitare che gli utenti ricevano un messaggio relativo ad un evento che si &egrave; gi&agrave; svolto.
</p>
