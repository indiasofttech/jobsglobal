
<h3>Il contenuto del messaggio</h3>

<p>Ci sono due modi per specificare il contenuto del vostro messaggio</p>

<h2>1. Inviare una pagina Web</h2>

<p>quando inviate una pagina web, tutto quello che dovete fare &egrave; specificare l'URL della pagina che volete mandare. Phplist scaricher&agrave; l'URL e lo invier&agrave; ai vostri utenti.</p>
<p>Le immagini appariranno nel sito che inviate.</p>

<h2>2. Comporre il contenuto</h2>

<p>Potete inserire il contenuto del messaggio nel riquadro sottostante.</p>
<p>Se lo avete configurato appositamente, potete caricare le immagini dal server phplist.</p>
     