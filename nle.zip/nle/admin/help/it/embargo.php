<b>Bloccare un messaggio</b>
<p>Potete blocare un messaggio per fare in modo che non sia inviato prima della data e ora che avete indicato.
L'orario predefinito sar&aacute; oggi alle ore 0:00, e quindi verr&agrave; inviato immediatamente. </p>
<p><b>Nota bene</b>: il blocco imposta il momento di inizio della spedizione del messaggio.
Questo per&ograve; non significa che i messaggi arriveranno nella caselle di posta degli utenti a quell'ora.
</p>
