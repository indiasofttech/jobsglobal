<p>Potete aggiungere al messaggio tutti gli allegati che volete, ma il numero qui
&egrave; definito nella vostra configurazione.</p>
<p><b>Nota bene:</b> Gli allegati saranno inclusi nelle email in formato HTML, e saranno aggiunti come link ai messaggi in formato testuale.</p>
<p>Il campo descrizione sar&aacute; usato solo nei messaggi in formato testuale.</p>
