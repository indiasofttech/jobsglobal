
<h3>Tasto elimina statistiche sulle visite e sui click</h3>

<p>Spuntate la casella per eliminare le statistiche esistenti sulle visite e sui click di questo messaggio.</p>
<p>Usate questa funzione se, per esempio, avete mandato e-mail di prova e avete cliccato sui link per essere sicuri che tutto funzioni come volete, il database dovrebbe contenere alcune statistiche su click che volete elimare.</p>
<p>Assicuratevi di aver spuntato correttamente questa casella una volta che la newsletter &egrave; iniziata, altrimenti verranno eliminate anche le statistiche dei veri utenti.</p>



  