<h3>Generare la versione di testo dalla versione in HTML</h3>

<p>Verr&agrave; usata la procedura di conversione del testo di phpList per precompilare la versione testuale del messaggio, in base al contenuto della versione HTML</p>
<p>Tutti i contenuti che sono gi&agrave; presenti nel campo per la versione testo saranno cancellati</p>

<p><b>Nota:</b>Questo processo non funziona quando il contenuto dell'HTML &egrave; troppo grande.</p>  