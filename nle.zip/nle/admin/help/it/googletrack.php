
<h3>Il codice di tracciamento di Google</h3>

<p>Se usate Google Analytics sul vostro sito, questo sar&agrave; molto utile per vedere i risultati dei messaggi</p>
<p>Selezionando questa opzione verranno aggiunti i codici per il tracciamento di tutti i collegamenti.
Dopo aver inviato il messaggio, controllate il vostro account su Google Analytics sotto la voce <strong>Risorse di traffico -&gt; Messaggi</strong> per vedere i risultati.</p>



