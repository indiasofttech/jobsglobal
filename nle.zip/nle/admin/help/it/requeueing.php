<h3>Re-invio di un messaggio</h3>

<p>Quando scegliete di re-inviare un messaggio, questo verr&agrave; rimesso in coda, una volta che l'invio sar&agrave; terminato.
Il blocco del messaggio verr&agrave; impostato in base al tempo e alla frequenza di re-invio che specificate qui.
</p>

<p>Questo far&agrave; in modo che il messaggio venga inviato agli utenti che si sono iscritti dopo l'invio.</p>

  