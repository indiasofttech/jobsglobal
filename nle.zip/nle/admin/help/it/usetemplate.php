<p>Se utilizzate un modello, questo messaggio verr&agrave; posto nella posizione dove si trova il segnalibro [CONTENT] nel vostro modello.</p>
<p>Oltre a [CONTENT], potete aggiungere [FOOTER] e [SIGNATURE] per inserire le informazioni nella riga a pi&egrave; di pagina e la firma del messaggio, tuttavia sono opzionali.</p>
