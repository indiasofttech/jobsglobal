
<h3>Inviare una pagina web</h3>

<p>Per inviare il contenuto di una pagina web ai vostri utenti dovete inserite l'URL nel riquadro sottostante.</p>

<p>Nel vostro URL, potete specificare alcuni dati relativi agli utenti:

<ul>
<li>[email] - l'e-mail dell'utente</li>
<li>[id] - L'ID dell'utente</li>
<li>[uniqid] - Il codice univoco dell'utente</li>
<li>[htmlemail] - la preferenza HTML dell'utente</li>
</ul>

</p>

<p><strong>Attenzione, l'utilizzo di URL specifici per gli utenti rallenter&agrave; sensibilemente l'invio dei messaggi.</strong></p>
 