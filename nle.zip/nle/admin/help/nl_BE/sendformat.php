Als dit bericht het HTML formaat heeft,
geef dan aan hoe je het wilt verzenden:<br />
<ul>
<li><b>HTML</b> - HTML aan gebruikers die hebben aangegeven dat ze emails in HTML formaat willen ontvangen, en tekst naar alle anderen</li>
<li><b>tekst</b> - pure tekst naar iedereen</li>
<li><b>tekst en HTML</b> - Een grote mail dat het HTML- en pure tekst formaat bevat (grotere emails, maar meest waarschijnlijk dat het werkt voor de meeste gebruikers)</li>
<li><b>PDF</b> - Het tekst bericht als een PDF bijlage</li>
<li><b>tekst en PDF</b> - Een email dat de pure tekst versie bevat met een PDF bijlage</li>
</ul>

<b>Let op:</b> de PDF versie zal een geconverteerde versie van de pure tekst versie zijn, niet van het HTML bericht.