<p>Als u een template gebruikt, dan zal het bericht worden geplaatst waar de markering [CONTENT] staat opgegeven in uw template.</p>
<p>Bijkomend bij [CONTENT], kan u ook [FOOTER] en [SIGNATURE] gebruiken om voetnoot en handtekening van het bericht mee te sturen. Deze zijn optioneel.</p>
