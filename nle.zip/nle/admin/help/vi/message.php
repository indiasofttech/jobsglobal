<p>Trong ph&#7847;n n&#7897;i dung  b&#7841;n c&oacute; th&#7875; d&ugrave;ng bi&#7871;n thu&#7897;c t&iacute;nh &#273;&#7875; thay cho c&aacute;c gi&aacute; tr&#7883; t&#432;&#417;ng &#7913;ng c&#7911;a ng&#432;&#7901;i nh&#7853;n:</p>
<p>  C&aacute;c bi&#7871;n thay th&#7871; ph&#7843;i &#273;&#432;&#7907;c &#273;&aacute;nh d&#7845;u trong ngo&#7863;c vu&ocirc;ng v&iacute; d&#7909; [NAME], &#7903; &#273;&acirc;y NAME s&#7869; &#273;&#432;&#7907;c thay b&#7903;i m&#7897;t trong c&aacute;c thu&#7897;c t&iacute;nh c&#7911;a ng&#432;&#7901;i nh&#7853;n. V&iacute; d&#7909; n&#7871;u b&#7841;n c&oacute; m&#7897;t thu&#7897;c t&iacute;nh &quot;First name&quot; th&igrave; d&ugrave;ng [FIRST NAME] trong th&ocirc;ng &#273;i&#7879;p n&#417;i m&agrave; T&ecirc;n c&#7911;a ng&#432;&#7901;i nh&#7853;n s&#7869; &#273;&#432;&#7907;c ch&egrave;n v&agrave;o.</p>
<p> Hi&#7879;n t&#7841;i b&#7841;n &#273;&atilde; &#273;&#7883;nh ngh&#297;a c&aacute;c thu&#7897;c t&iacute;nh c&oacute; th&#7875; d&ugrave;ng sau:
</p>
</p>

<?php

print listPlaceHolders();

if (phplistPlugin::isEnabled('rssmanager')) {
    ?>
  <p>B&#7841;n c&oacute; th&#7875; l&#7853;p s&atilde;n m&#7897;t th&#432; c&oacute; th&#7875; &#273;&#432;&#7907;c g&#7917;i  t&#7921; &#273;&#7897;ng  cho h&#7897;i vi&ecirc;n v&#7899;i giao th&#7913;c RSS. &#272;&#7875; l&agrave;m &#273;&#432;&#7907;c &#273;i&#7873;u n&agrave;y, h&atilde;y ch&#7885;n m&#7909;c &quot;&#272;&#7863;t l&#7883;ch&quot; v&agrave; ch&#7881; ra t&#7847;n su&#7845;t g&#7917;i th&#432;.  B&#7841;n c&#7847;n s&#7917; d&#7909;ng h&#7897;p ch&#7913;a [RSS] trong th&ocirc;ng &#273;i&#7879;p n&#417;i b&#7841;n mu&#7889;n th&#7875; hi&#7879;n n&#7897;i dung l&#7845;y v&#7873; t&#7915; ngu&#7891;n tin RSS .</p>
  <?php 
}
?>

<p>&#272;&#7875; g&#7917;i n&#7897;i dung c&#7911;a m&#7897;t trang web, th&ecirc;m &#273;&#432;&#7901;ng d&#7851;n c&#7911;a trang web &#273;&oacute; v&#7899;i &#273;&#7883;nh d&#7841;ng sau v&agrave;o th&ocirc;ng &#273;i&#7879;p c&#7911;a b&#7841;n:<br/>
<b>[URL:</b>http://www.example.org/path/to/file.html<b>]</b></p>
<p>B&#7841;n c&oacute; th&#7875; th&ecirc;m c&aacute;c th&ocirc;ng tin c&#417; b&#7843;n v&#7873; ng&#432;&#7901;i nh&#7853;n trong &#273;&#432;&#7901;ng d&#7851;n, kh&ocirc;ng ph&#7843;i th&ocirc;ng tin thu&#7897;c t&iacute;nh khai b&aacute;o &#7903; tr&ecirc;n:</br>
<b>[URL:</b>http://www.example.org/userprofile.php?email=<b>[</b>email<b>]]</b><br/>
</p>
