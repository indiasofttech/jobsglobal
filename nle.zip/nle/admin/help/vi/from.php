B&#7841;n c&oacute; th&#7875; d&ugrave;ng ba c&aacute;ch kh&aacute;c nhau cho tr&#432;&#7901;ng t&ecirc;n ng&#432;&#7901;i g&#7917;i (From):
<ul>
  <li>M&#7897;t t&#7915;: s&#7869; &#273;&#432;&#7907;c &#273;&#7883;nh d&#7841;ng l&#7841;i th&agrave;nh <b>&lt;t&#7915; g&otilde; v&agrave;o&gt;@<?php echo $domain?></b> <br>
    V&iacute; d&#7909;: <b>information</b> s&#7869; th&agrave;nh <b>information@<?php echo $domain?></b>
    <br>
  Trong h&#7847;u h&#7871;t c&aacute;c &#7913;ng d&#7909;ng email, n&oacute; s&#7869; hi&#7875;n th&#7883; l&agrave; <b>information@<?php echo $domain?></b> <br>
  </li>
  <li> Hai t&#7915; tr&#7903; l&ecirc;n: s&#7869; tr&#7903; th&agrave;nh <i>T&#7915; b&#7841;n g&otilde;</i> v&agrave; <b>&lt;listmaster@<?php echo $domain?>&gt;</b>
    <br>
    V&iacute; d&#7909;: <b>list information</b> s&#7869; th&agrave;nh <b>list information &lt;listmaster@<?php echo $domain?>&gt;</b> 
    <br>
    Trong h&#7847;u h&#7871;t c&aacute;c &#7913;ng d&#7909;ng email, n&oacute; s&#7869; hi&#7875;n th&#7883; l&agrave; <b>list information</b>
    <br>
  </li>
  <li>Cho v&agrave;o m&#7897;t v&agrave;i t&#7915; v&agrave; m&#7897;t &#273;&#7883;a ch&#7881; email: s&#7869; th&agrave;nh <i><b>T&#7915; g&otilde; v&agrave;o</b></i> <b>&lt;&#273;&#7883;a ch&#7881; email&gt;
    </b><br>
    V&iacute; d&#7909;: <b>My Name my@email.com</b> s&#7869; th&agrave;nh <b>My Name &lt;my@email.com<br>
  </b>Trong h&#7847;u h&#7871;t c&aacute;c &#7913;ng d&#7909;ng email, n&oacute; s&#7869; hi&#7875;n th&#7883; l&agrave; <b>My Name</b></b></li>
</ul>
