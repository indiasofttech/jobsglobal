Ta opcja pozwala na automatyczne utworzenie przez system nowej wiadomości,
która będzie dokładną kopią bieżącej wiadomości, w określonych przez Ciebie odstępach czasu.
Jeśli używasz tej opcji, ważne jest abyś skorzystał także z opcji "Ograniczenie do", w przeciwnym wypadku
wiadomośc będzie wysyłana ciągle, zalewając użytkowników dużą ilością tych samych wiadomości.

