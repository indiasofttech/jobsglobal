<p>Jeśli używasz szblonu, wiadomośc zostanie wstawiona w miejscu symbolu [CONTENT] użytego w szablonie.</p>
<p>Oprócz [CONTENT], możesz dodać [FOOTER] oraz [SIGNATURE] aby wstawić stopkę i podpis wiadomości, jednak jest to opcjonalne.</p>
