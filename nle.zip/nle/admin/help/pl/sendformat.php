Jeśli sformatowano wiadomość przy użyciu HTML,
nalezy wskazać jak ma być wysłana:<br />
<ul>
<li><b>HTML</b> - HTML z ukrytym tekstem tylko do użytkowników, którzy wskazali, że chcą odbierać wiadomości w formacie HTML, a tekstowe do wszystkich innych</li>
<li><b>tekst</b> - tylko tekstowe do wszystkich</li>
<!-- li><b>text and HTML</b> - One big email that contains both the HTML and the text only format.</li> -->
<li><b>PDF</b> - Wiadomość tekstowa jako załącznik PDF</li>
<li><b>tekst and PDF</b> - jedna wiadomość zawierająca tekstową treść z załącznikiem PDF</li>
</ul>

<b>Uwaga:</b> wersja PDF wnędzie konwersją treści tekstowej a nie HTML.