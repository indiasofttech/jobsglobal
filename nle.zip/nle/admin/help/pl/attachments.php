<p>Możesz dodać dowolną liczbę załączników do wiadomości, lecz ilość wyświetlonych tutaj
jest zdefiniowana w konfiguracji.</p>
<p><b>Uwaga:</b> Załączniki zostaną dołączone do wiadomości wysyłanych jako HTML, natomiast w wiadomościach tekstowych zostaną dodane jako link do strony internetowej</p>
<p>Pole Opis zostanie użyte tylko w wiadomościach tekstowych</p>