<b>Ograniczenie wysyłania wiadomości</b>
<p>Możesz ograniczyć wysyłanie wiadomości - wiadomośc zostanie wysłana po dacie i godzinie, którą ustawisz.
Domyślnie ustawione jest na dziś o godzinie 0:00 więc wiadomość zostanie wysłana natychmiast. </p>
<p><b>Uwaga</b>: Ograniczenie wysyłania ma wpływ na początek rozsyłania wiadomości. 
Nie oznacza to jednak, że wiadomości dotrą do odbiorcy o godzinie, którą ustawisz.
</p>