Naslov kampanje je samo za vašu upotrebu. Nije vidljiv vašim pretplatnicima i neće biti korišćen u odlaznim email-ovima.

