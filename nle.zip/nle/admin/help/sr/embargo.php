<b>Odloži poruku</b>
<p>Možete odložiti slanje poruke tako da se ne pošalje pre datuma i vremena koje navedete.
Podrazumevano podešavanje je danas u 0:00, tako da će biti poslata odmah. </p>
<p><b>Molimo obratite pažnju</b>: odlaganje ima efekta na vreme početka slanja vaše poruke.
Ovo ne znači da će poruke stvarno biti primljene u korisničko sanduče u to vreme.
</p>