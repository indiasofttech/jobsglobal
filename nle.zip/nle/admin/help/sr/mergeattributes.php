<p>Napomena o spajanju atributa.</p>
<p>Spajanje atributa znači da će korisničke vrednosti ostati iste, ali da će
aktuelan atribut kome pripadaju biti pripojen u jedan. Atribut koji će ostati
je prvi (po redosledu, kako ga vidite na strani).</p>
<ul>
<li>Možete spojiti samo atribute istog tipa</li>
<li>Pri spajanju, vrednost prvog atributa će biti zadržana, ako postoji, inače
će biti prepisana vrednošću atributa koji se pripaja. Ovo može izazvati gubitak
podataka, u slučaju da su oba atributa imala vrednost. </li>
<li>Ako spojite atribute tipa <i>checkbox</i> rezultujući spojeni atribut će biti <i>checkboxgroup</i> tipa.</li>
<li>Atributi koji se spajaju sa drugim atributom će biti obrisani posle spajanja.</li>
</ul>
