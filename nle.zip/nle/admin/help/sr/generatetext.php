
<h3>Generisati tekst verziju iz HTML-a</h3>

<p>Ovo će iskoristiti phpList HTML u tekst konverziju da napravi tekst verziju kampanje, na osnovu sadržaja HTML verzije</p>
<p>Sadržaj koji je već u polju za unos teksta će biti uklonjen.</p>

<p><b>Napomena:</b> ovaj proces će biti neuspešan kada je HTML sadržaj veoma velik.</p>
