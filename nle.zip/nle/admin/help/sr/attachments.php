<p>Možete dodati koliko hoćete priloga u vašu poruku, ali je broj prikazan ovde
definisan u vašoj konfiguraciji.</p>
<p><b>Molimo obratite pažnju:</b> Prilozi će biti ubačeni u HTML email-ove, a biće dodati kao linkovi ka veb sajtu u tekstualnim email-ovima</p>
<p>Polje opisa će se koristiti samo u tekstualnim porukama</p>