
<h3>Pošalji veb stranu</h3>

<p>Da pošaljete sadržaj veb strane vašim pretplatnicima, samo unesite URL u polje ispod</p>

<p>Možete naznačiti neke specifične podatke pretplatnika u vašem URL-u:

<ul>
<li>[email] - email pretplatnika</li>
<li>[id] - ID pretplatnika</li>
<li>[uniqid] - Jedinstveni Kod pretplatnika</li>
<li>[htmlemail] - HTML podešavanje pretplatnika</li>
</ul>

</p>

<p><strong>Upozorenje, korišćenje URL-ova sa specifičnim korisničkim podacima će dramatično usporiti slanje poruka</strong></p>
