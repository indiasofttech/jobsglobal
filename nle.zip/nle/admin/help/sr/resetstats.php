
<h3>Resetuj statistiku za klikove i otvorene</h3>

<p>Označite polje da obrišete postojeću statistiku klikova i otvorenih poruka za ovu kampanju.</p>
<p>Ako ste slali test email-ove i kliktali na linkove, da bi se uverili da sve radi kao što želite, baza podataka može sadržati neku statistiku klikova koju želite da obrišete.</p>
<p>Postarajte se da ne označite ovo polje kada započnete vašu glavnu kampanju, inače će statistika za prave pretplatnike isto biti obrisana.</p>



