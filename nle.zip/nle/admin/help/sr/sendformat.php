Ako je ova poruka formatirana u HTML-u,
naznačite kako želite da je pošaljete:<br />
<ul>
<li><b>HTML</b> - HTML sa sakrivenim tekstom za korisnike koji su naznačili da žele da primaju svoje email-ove u HTML formatu, a samo tekst svim ostalima</li>
<li><b>tekst</b> - samo tekst svima</li>
<li><b>PDF</b> - Tekstualna poruka kao PDF prilog</li>
<li><b>tekst i PDF</b> - Jedan email koji sadrži tekstualnu poruku sa PDF prilogom</li>
</ul>

<b>Obratite pažnju:</b> PDF verzija će biti konverzija tekstualne poruke, ne HTML poruke.
