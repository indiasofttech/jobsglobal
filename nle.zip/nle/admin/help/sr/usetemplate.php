<p>Ako koristite obrazac, ova poruka će biti stavljena na mesto [CONTENT] zamenskog teksta u vašem obrascu.</p>
<p>Pored [CONTENT], možete dodati [FOOTER] i [SIGNATURE] da bi ubacili informacije podnožja i potpis poruke, ali su oni opcioni.</p>
