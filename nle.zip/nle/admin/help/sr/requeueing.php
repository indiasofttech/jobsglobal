
<h3>Vrati kampanju u red za slanje</h3>

<p>kada odaberete da vratite kampanju u red za slanje, kampanja će biti ponovo stavljena u red za slanje, po završetku slanja.
Embargo kampanje će biti podešen na vreme uvećano za frekvenciju ponovnog slanja koju naznačite ovde.
</p>

<p>Ovo će učiniti da se kampanja pošalje pretplatnicima koji su se pretplatili posle prethodnog slanja kampanje.</p>

