
<h3>Sadržaj vaše kampanje</h3>

<p>Postoje dva načina da naznačite sadržaj vaše kampanje</p>

<h2>1. Pošalji Veb stranu</h2>

<p>Kada šaljete veb stranu, sve što je potrebno da naznačite je URL veb strane koju želite da pošaljete. phpList će uzeti URL, i poslati ga vašim pretplatnicima.</p>
<p>Slike će biti na vebsajtu koji šaljete.</p>

<h2>2. Napišite sadržaj</h2>

<p>Možete uneti sadržaj vaše kampanje u polju ispod.</p>
<p>Ako ste prethodno podesili, možete otpremiti slike na phpList server.</p>
