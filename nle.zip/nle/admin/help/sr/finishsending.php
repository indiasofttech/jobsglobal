<h3>Zaustavi slanje posle</h3>
<p>Da bi bili sigurni da se vaša kampanja ne nastavi slati posle određenog vremena, podesite ovu vrednost.</p>
<p>Ovo je naročito korisno ako vaša kampanja obuhvata neki događaj u budućnosti. Korišćenjem ovom podešavanja, možete
da izbegnete da vaši pretplatnici prime poruku pošto je događaj prošao.
</p>
