
<h3>Google kod za praćenje</h3>

<p>Ako koristite Google Analytics na vašem veb sajtu, ovo je odličan način da vidite rezultate vaše kampanje.</p>
<p>Odabit ove opcije će dodati neki kod za praćenje na sve linkove.
Posle slanja vaše kampanje, proverite vaš Google Analytics nalog pod <strong>Traffic sources -&gt; Campaigns</strong> da vidite rezultate.</p>

<p>Ne koristite ovo ako vaša kampanja već sadrži, zato što će se postojeći biti uklonjeni.</p>

