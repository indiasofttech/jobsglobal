
<h3>Test kampanja</h3>

<p>Ako šaljete ovu kampanju kao test malom broju pretplatnika, označite kutiju.</p>
<p>Ovo će dodati opciju da se kampanja obriše sa liste završenih ili aktivnih kampanja.</p>

<p>Nije preporučljivo da ovo uradite na vašim konačnim kampanjama, zato što će brisanje kampanje izazvati da svi linkovi u poruci, koju su primili vaši pretplatnici, prestanu raditi. Kada pretplatnik klikne na link u kampanji koja više ne postoji, dobiće "404 - File Not Found" poruku o grešci.</p>



