Unesite naslov vaše kampanje. Ne možete koristiti zamenske tekstove u naslovu. Ovo je prva stvar koju vide vaši pretplatnici, tako da je veoma važno da izaberete dobar naslov.
