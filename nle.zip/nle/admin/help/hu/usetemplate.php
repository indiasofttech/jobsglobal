<p>Ha sablont használ, akkor ez az üzenet a [CONTENT] helyőrző helyén kerül behelyettesítésre a sablonban.</p>
<p>A [CONTENT] helyőrzőn kívül a [FOOTER] és a [SIGNATURE] helyőrzővel szúrhatja be a lábléc adatait és az üzenet eláírását, ezek azonban elhagyhatóak.</p>
