Ha ez egy HTML-ben formázott üzenet,
akkor jelezze, hogyan kívánja kiküldeni:<br />
<ul>
<li><b>HTML</b> - HTML rejtett szöveggel csak azoknak a felhasználóknak, akik jelezték, hogy HTML formátumban kérik az e-maileket, s mindenki másnak csak szöveg</li>
<li><b>szöveg</b> - csak szöveg mindenkinek</li>
<!-- li><b>text and HTML</b> - One big email that contains both the HTML and the text only format.</li> -->
<li><b>PDF</b> - A szöveges üzenet PDF-mellékletként</li>
<li><b>szöveg és PDF</b> - Egy e-mail, mely PDF-melléklettel csak a szöveges üzenetet tartalmazza</li>
</ul>

<b>Please note:</b> the PDF version will be a conversion of the text message, not of the HTML message.